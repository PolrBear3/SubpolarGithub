Compress-Archive -Path './' -DestinationPath 'studio-theme.zip'
Rename-Item -path 'studio-theme.zip' -NewName 'studio-theme.aseprite-extension'